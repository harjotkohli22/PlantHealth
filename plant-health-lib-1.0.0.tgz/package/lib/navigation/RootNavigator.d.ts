import React from 'react';
export default function RootNavigator(): React.JSX.Element;
//# sourceMappingURL=RootNavigator.d.ts.map