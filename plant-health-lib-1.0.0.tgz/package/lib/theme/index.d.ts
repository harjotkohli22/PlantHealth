export declare const colors: {
    bg: string;
    surface: string;
    surfaceAlt: string;
    primary: string;
    primaryDark: string;
    accent: string;
    danger: string;
    warn: string;
    text: string;
    textDim: string;
    border: string;
};
export declare const spacing: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
};
export declare const radius: {
    sm: number;
    md: number;
    lg: number;
    pill: number;
};
export declare const font: {
    h1: number;
    h2: number;
    h3: number;
    body: number;
    small: number;
    tiny: number;
};
export declare const severityColor: (s: "healthy" | "mild" | "moderate" | "severe") => string;
//# sourceMappingURL=index.d.ts.map