export * from './imageToTensor';
//# sourceMappingURL=index.d.ts.map