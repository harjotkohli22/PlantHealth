export declare function imageFileToTensor(uri: string): Promise<Uint8Array>;
//# sourceMappingURL=imageToTensor.d.ts.map