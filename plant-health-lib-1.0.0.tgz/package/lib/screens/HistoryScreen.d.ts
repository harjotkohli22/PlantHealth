import React from 'react';
export default function HistoryScreen({ navigation }: any): React.JSX.Element;
//# sourceMappingURL=HistoryScreen.d.ts.map