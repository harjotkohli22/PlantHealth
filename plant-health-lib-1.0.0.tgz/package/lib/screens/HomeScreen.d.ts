import React from 'react';
export default function HomeScreen({ navigation }: any): React.JSX.Element;
//# sourceMappingURL=HomeScreen.d.ts.map