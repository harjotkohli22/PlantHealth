import React from 'react';
export default function ScanScreen({ navigation, route }: any): React.JSX.Element;
//# sourceMappingURL=ScanScreen.d.ts.map