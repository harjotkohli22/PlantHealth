import React from 'react';
export default function ResultScreen({ navigation, route }: any): React.JSX.Element;
//# sourceMappingURL=ResultScreen.d.ts.map