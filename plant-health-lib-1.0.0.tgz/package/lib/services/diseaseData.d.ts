/**
 * Label map for the PlantVillage-style classifier (38 classes).
 * Index order MUST match the model's output tensor order.
 * Replace with your model's actual label order if you retrain.
 */
export type Severity = 'healthy' | 'mild' | 'moderate' | 'severe';
export interface DiseaseInfo {
    label: string;
    crop: string;
    name: string;
    healthy: boolean;
    severity: Severity;
    summary: string;
    remedies: string[];
    prevention: string[];
}
export declare const LABELS: string[];
export declare function getDiseaseInfo(label: string): DiseaseInfo;
//# sourceMappingURL=diseaseData.d.ts.map