import { TensorflowModel } from 'react-native-fast-tflite';
import { DiseaseInfo } from './diseaseData';
export interface Prediction {
    info: DiseaseInfo;
    confidence: number;
    topK: {
        label: string;
        confidence: number;
    }[];
}
declare const MODEL_INPUT_SIZE = 224;
declare class PlantClassifier {
    private model;
    private loading;
    /** Lazy-load and cache the model. GPU delegate on Android, CoreML on iOS. */
    load(): Promise<TensorflowModel>;
    isReady(): boolean;
    /**
     * Run inference on a Float32 RGB buffer already resized to 224x224.
     * `rgb` is length 224*224*3 with values 0..255.
     */
    classify(rgb: Float32Array | Uint8Array): Promise<Prediction>;
    private normalize;
}
export declare const classifier: PlantClassifier;
export { MODEL_INPUT_SIZE };
//# sourceMappingURL=classifier.d.ts.map