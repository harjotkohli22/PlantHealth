export type { ScanRecord } from '../contexts/HistoryContext';
export { useHistoryContext as useHistory } from '../contexts/HistoryContext';
//# sourceMappingURL=useHistory.d.ts.map