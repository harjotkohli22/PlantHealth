import { Prediction } from '../services/classifier';
export declare function useFrameClassifier(enabled: boolean, intervalMs?: number): {
    frameProcessor: import("react-native-vision-camera").ReadonlyFrameProcessor;
    prediction: Prediction | null;
    running: boolean;
    setRunning: import("react").Dispatch<import("react").SetStateAction<boolean>>;
    isPlantDetected: boolean;
};
//# sourceMappingURL=useFrameClassifier.d.ts.map