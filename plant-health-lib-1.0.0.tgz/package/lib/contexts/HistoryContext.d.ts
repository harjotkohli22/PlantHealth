import React from 'react';
import type { Prediction } from '../services/classifier';
export interface ScanRecord {
    id: string;
    uri: string;
    label: string;
    crop: string;
    name: string;
    healthy: boolean;
    severity: string;
    confidence: number;
    topK: {
        label: string;
        confidence: number;
    }[];
    date: number;
}
interface HistoryContextValue {
    records: ScanRecord[];
    loaded: boolean;
    add: (uri: string, p: Prediction) => ScanRecord;
    remove: (id: string) => void;
    clear: () => void;
}
export declare function HistoryProvider({ children }: {
    children: React.ReactNode;
}): React.JSX.Element;
export declare function useHistoryContext(): HistoryContextValue;
export {};
//# sourceMappingURL=HistoryContext.d.ts.map