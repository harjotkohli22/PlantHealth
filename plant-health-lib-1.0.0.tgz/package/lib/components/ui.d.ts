import React from 'react';
import { ViewStyle } from 'react-native';
import type { Severity } from '../services/diseaseData';
export declare const TrashIcon: React.FC<{
    size?: number;
    color?: string;
}>;
export declare const Card: React.FC<{
    children: React.ReactNode;
    style?: ViewStyle;
}>;
export declare const Button: React.FC<{
    label: string;
    onPress: () => void;
    variant?: 'primary' | 'ghost' | 'danger';
    loading?: boolean;
    icon?: React.ReactNode;
}>;
export declare const SeverityBadge: React.FC<{
    severity: Severity;
}>;
export declare const ConfidenceBar: React.FC<{
    value: number;
}>;
export declare const ConfirmSheet: React.FC<{
    visible: boolean;
    title: string;
    message?: string;
    confirmLabel?: string;
    onConfirm: () => void;
    onClose: () => void;
}>;
//# sourceMappingURL=ui.d.ts.map